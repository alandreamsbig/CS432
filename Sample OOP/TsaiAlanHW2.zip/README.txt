Alan Tsai
HW2 CS432

Everything should work. I made the brightness of the shapes change very fast to look cool so when you rotate, it flashes.  