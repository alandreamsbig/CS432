Alan Tsai
HW4

The program was build in VS. It should draw the sphere using recursion, and 
the plane. The flying camera should work and can toggle between different 
camera view using spacebar.