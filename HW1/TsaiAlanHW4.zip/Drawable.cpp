#include "Drawable.h"

void Drawable::draw()
{}
void Drawable::drawSphere()
{}
