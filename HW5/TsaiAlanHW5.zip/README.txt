Alan Tsai
HW5

The program was written using VS.
It uses fragment shading for the light.
There should be a flying camera, a directional
light/flashlight and a scene being a plane,
sphere and cube.