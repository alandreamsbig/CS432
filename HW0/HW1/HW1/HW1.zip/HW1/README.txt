Alan Tsai
CS432 HW1
There are 4 glsl files that needs to be in the project. The project was developed in Visual Studio, everything
should display and work.