//SAMPLE CODE
//3D Graphics


#include "Angel.h"  //includes gl.h, glut.h and other stuff...
#include "Camera.h";
#include "Sphere.h";
#include "Triangle.h";
#include "Cube.h";
#include "Skybox.h";
#include "Plane.h";
#include "Light.h";
#include "CubeMap.h";
#include "Roof.h";
#include "Snowflake.h";
#include <iostream>
#include <fstream>
#include <time.h>


/*

std::string vertices[] = {
	"vec4(-0.191467,0.148427,-0.049359,1.0)",
	"vec4(-0.191467,0.148427,0.011199,1.0)",
	"vec4(-0.191467,0.087869,0.011199,1.0)",
	"vec4(-0.191467,0.087869,-0.049359,1.0)",
	"vec4(-0.433699,0.148427,-0.049359,1.0)",
	"vec4(-0.433699,0.148427,0.011199,1.0)",
	"vec4(-0.433699,0.087869,0.011199,1.0)",
	"vec4(-0.433699,0.087869,-0.049359,1.0)",
	"vec4(0.450354,-0.086344,-0.049359,1.0)",
	"vec4(0.450354,-0.086344,0.011199,1.0)",
	"vec4(0.450354,-0.146902,0.011199,1.0)",
	"vec4(0.450354,-0.146902,-0.049359,1.0)",
	"vec4(0.208123,-0.086344,-0.049359,1.0)",
	"vec4(0.208123,-0.086344,0.011199,1.0)",
	"vec4(0.208123,-0.146902,0.011199,1.0)",
	"vec4(0.208123,-0.146902,-0.049359,1.0)",
	"vec4(0.356613,-0.306162,-0.049359,1.0)",
	"vec4(0.356613,-0.306162,0.011199,1.0)",
	"vec4(0.304169,-0.336441,0.011199,1.0)",
	"vec4(0.304169,-0.336441,-0.049359,1.0)",
	"vec4(0.235498,-0.096384,-0.049359,1.0)",
	"vec4(0.235498,-0.096384,0.011199,1.0)",
	"vec4(0.183053,-0.126663,0.011199,1.0)",
	"vec4(0.183053,-0.126663,-0.049359,1.0)",
	"vec4(-0.171237,0.137771,-0.049359,1.0)",
	"vec4(-0.171237,0.137772,0.011199,1.0)",
	"vec4(-0.223682,0.107493,0.011199,1.0)",
	"vec4(-0.223682,0.107493,-0.049359,1.0)",
	"vec4(-0.292353,0.347550,-0.049359,1.0)",
	"vec4(-0.292353,0.347550,0.011199,1.0)",
	"vec4(-0.344797,0.317271,0.011199,1.0)",
	"vec4(-0.344797,0.317271,-0.049359,1.0)",
	"vec4(0.441504,-0.213143,-0.047317,1.0)",
	"vec4(0.441504,-0.213143,0.013241,1.0)",
	"vec4(0.411225,-0.265588,0.013241,1.0)",
	"vec4(0.411225,-0.265587,-0.047317,1.0)",
	"vec4(-0.397610,0.271320,-0.047317,1.0)",
	"vec4(-0.397610,0.271320,0.013241,1.0)",
	"vec4(-0.427889,0.218875,0.013241,1.0)",
	"vec4(-0.427889,0.218875,-0.047317,1.0)",
	"vec4(0.231583,0.102531,-0.049359,1.0)",
	"vec4(0.231583,0.102531,0.011199,1.0)",
	"vec4(0.179139,0.132810,0.011199,1.0)",
	"vec4(0.179139,0.132810,-0.049359,1.0)",
	"vec4(0.352699,0.312309,-0.049359,1.0)",
	"vec4(0.352699,0.312309,0.011199,1.0)",
	"vec4(0.300254,0.342588,0.011199,1.0)",
	"vec4(0.300254,0.342588,-0.049359,1.0)",
	"vec4(-0.292645,-0.335917,-0.049359,1.0)",
	"vec4(-0.292645,-0.335917,0.011199,1.0)",
	"vec4(-0.345089,-0.305638,0.011199,1.0)",
	"vec4(-0.345089,-0.305638,-0.049359,1.0)",
	"vec4(-0.171529,-0.126139,-0.049359,1.0)",
	"vec4(-0.171529,-0.126139,0.011199,1.0)",
	"vec4(-0.223974,-0.095860,0.011199,1.0)",
	"vec4(-0.223974,-0.095860,-0.049359,1.0)",
	"vec4(-0.436143,-0.144826,-0.049359,1.0)",
	"vec4(-0.436143,-0.144826,0.011199,1.0)",
	"vec4(-0.436143,-0.084268,0.011199,1.0)",
	"vec4(-0.436143,-0.084268,-0.049359,1.0)",
	"vec4(-0.193912,-0.144826,-0.049359,1.0)",
	"vec4(-0.193912,-0.144826,0.011199,1.0)",
	"vec4(-0.193912,-0.084268,0.011199,1.0)",
	"vec4(-0.193912,-0.084268,-0.049359,1.0)",
	"vec4(0.212240,0.090339,-0.049359,1.0)",
	"vec4(0.212240,0.090339,0.011199,1.0)",
	"vec4(0.212240,0.150897,0.011199,1.0)",
	"vec4(0.212240,0.150897,-0.049359,1.0)",
	"vec4(0.454472,0.090339,-0.049359,1.0)",
	"vec4(0.454472,0.090339,0.011199,1.0)",
	"vec4(0.454472,0.150897,0.011199,1.0)",
	"vec4(0.454472,0.150897,-0.049359,1.0)",
	"vec4(-0.398031,-0.264853,-0.047317,1.0)",
	"vec4(-0.398031,-0.264853,0.013241,1.0)",
	"vec4(-0.428310,-0.212409,0.013241,1.0)",
	"vec4(-0.428310,-0.212409,-0.047317,1.0)",
	"vec4(0.441083,0.219609,-0.047317,1.0)",
	"vec4(0.441083,0.219609,0.013241,1.0)",
	"vec4(0.410804,0.272054,0.013241,1.0)",
	"vec4(0.410804,0.272054,-0.047317,1.0)",
	"vec4(0.033307,0.247603,-0.049359,1.0)",
	"vec4(0.033307,0.247603,0.011199,1.0)",
	"vec4(-0.019138,0.217324,0.011199,1.0)",
	"vec4(-0.019138,0.217324,-0.049359,1.0)",
	"vec4(-0.087809,0.457382,-0.049359,1.0)",
	"vec4(-0.087809,0.457382,0.011199,1.0)",
	"vec4(-0.140253,0.427103,0.011199,1.0)",
	"vec4(-0.140253,0.427103,-0.049359,1.0)",
	"vec4(0.150900,-0.425616,-0.049359,1.0)",
	"vec4(0.150900,-0.425616,0.011199,1.0)",
	"vec4(0.098455,-0.455895,0.011199,1.0)",
	"vec4(0.098455,-0.455895,-0.049359,1.0)",
	"vec4(0.029784,-0.215837,-0.049359,1.0)",
	"vec4(0.029784,-0.215837,0.011199,1.0)",
	"vec4(-0.022660,-0.246116,0.011199,1.0)",
	"vec4(-0.022660,-0.246116,-0.049359,1.0)",
	"vec4(-0.086339,-0.454343,-0.049359,1.0)",
	"vec4(-0.086339,-0.454343,0.011199,1.0)",
	"vec4(-0.138783,-0.424064,0.011199,1.0)",
	"vec4(-0.138783,-0.424064,-0.049359,1.0)",
	"vec4(0.034777,-0.244565,-0.049359,1.0)",
	"vec4(0.034777,-0.244565,0.011199,1.0)",
	"vec4(-0.017668,-0.214286,0.011199,1.0)",
	"vec4(-0.017668,-0.214286,-0.049359,1.0)",
	"vec4(0.034194,0.224756,-0.049359,1.0)",
	"vec4(0.034194,0.224756,0.011199,1.0)",
	"vec4(-0.018250,0.255035,0.011199,1.0)",
	"vec4(-0.018250,0.255035,-0.049359,1.0)",
	"vec4(0.155310,0.434534,-0.049359,1.0)",
	"vec4(0.155310,0.434534,0.011199,1.0)",
	"vec4(0.102865,0.464813,0.011199,1.0)",
	"vec4(0.102865,0.464813,-0.049359,1.0)",
	"vec4(0.036664,-0.481351,-0.047317,1.0)",
	"vec4(0.036664,-0.481351,0.013241,1.0)",
	"vec4(-0.023894,-0.481351,0.013241,1.0)",
	"vec4(-0.023894,-0.481351,-0.047317,1.0)",
	"vec4(0.036664,0.487574,-0.047317,1.0)",
	"vec4(0.036664,0.487574,0.013241,1.0)",
	"vec4(-0.023894,0.487574,0.013241,1.0)",
	"vec4(-0.023894,0.487574,-0.047317,1.0)",
};


int indices[] = {
	2,4,1,8,6,5,5,2,1,6,3,2,7,4,3,5,4,8,10,12,9,16,14,13,13,10,9,14,11,10,15,12,11,9,16,13,17,19,20,24,22,21,21,18,17,18,23,19,23,20,19,21,20,24,25,27,28,29,31,30,29,26,25,26,31,27,31,28,27,29,28,32,34,36,33,37,39,38,37,34,33,34,39,35,39,36,35,33,40,37,42,44,41,48,46,45,41,46,42,46,43,42,43,48,44,41,48,45,50,52,49,56,54,53,53,50,49,54,51,50,55,52,51,49,56,53,58,60,57,61,63,62,57,62,58,58,63,59,63,60,59,57,64,61,66,68,65,72,70,69,69,66,65,70,67,66,71,68,67,69,68,72,74,76,73,80,78,77,77,74,73,74,79,75,79,76,75,73,80,77,82,84,81,88,86,85,81,86,82,86,83,82,87,84,83,81,88,85,90,92,89,96,94,93,93,90,89,94,91,90,95,92,91,89,96,93,97,99,100,104,102,101,101,98,97,102,99,98,103,100,99,97,104,101,105,107,108,112,110,109,109,106,105,110,107,106,111,108,107,109,108,112,114,116,113,117,119,118,117,114,113,118,115,114,119,116,115,113,120,117,2,3,4,8,7,6,5,6,2,6,7,3,7,8,4,5,1,4,10,11,12,16,15,14,13,14,10,14,15,11,15,16,12,9,12,16,17,18,19,24,23,22,21,22,18,18,22,23,23,24,20,21,17,20,25,26,27,29,32,31,29,30,26,26,30,31,31,32,28,29,25,28,34,35,36,37,40,39,37,38,34,34,38,39,39,40,36,33,36,40,42,43,44,48,47,46,41,45,46,46,47,43,43,47,48,41,44,48,50,51,52,56,55,54,53,54,50,54,55,51,55,56,52,49,52,56,58,59,60,61,64,63,57,61,62,58,62,63,63,64,60,57,60,64,66,67,68,72,71,70,69,70,66,70,71,67,71,72,68,69,65,68,74,75,76,80,79,78,77,78,74,74,78,79,79,80,76,73,76,80,82,83,84,88,87,86,81,85,86,86,87,83,87,88,84,81,84,88,90,91,92,96,95,94,93,94,90,94,95,91,95,96,92,89,92,96,97,98,99,104,103,102,101,102,98,102,103,99,103,104,100,97,100,104,105,106,107,112,111,110,109,110,106,110,111,107,111,112,108,109,105,108,114,115,116,117,120,119,117,118,114,118,119,115,119,120,116,113,116,120 
};

void test() {
	std::ofstream myfile;
	myfile.open("example.txt");	
	//std::cout << std::endl << std::endl << std::endl;
	//std::cout << "vec4 fullVertices[] = {\n";
	myfile << "vec4 fullVertices[] = {\n";
	for (int i = 0; i < 20520; i++)
	{
		//std::cout << vertices[indices[i]-1] << ",\n";
		myfile << vertices[indices[i] - 1] << ",\n";
	}

	//std::cout << "};";
	myfile << "};";
	std::cout << std::endl << std::endl << std::endl;

	myfile.close();
}

*/

void test();


vec4 black_opaque = vec4(0.0,0.0,0.0,1.0);
void timerCallback(int value);
void snowflaketimer(int value);
int theta;

//Foward declarations of functions

void init();
void display();
void resize(int w, int h);
void keyboard(unsigned char, int, int);
void keyboardSpecial(int key, int x, int y);
void close();
void mymouse(GLint button, GLint state, GLint x, GLint y);


std::string textures[] = { "crate1.ppm", "crate2.ppm" };
int currTexture = 0;
//----------------------------------------------------------------------------
int main( int argc, char **argv )
{
	srand(time(0));
    glutInit( &argc, argv );	//initialize glut
	#ifdef __APPLE__
    glutInitDisplayMode( GLUT_3_2_CORE_PROFILE|GLUT_RGBA | GLUT_SINGLE|GLUT_DEPTH);
#else
    glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE |GLUT_DEPTH);
#endif
    glutInitWindowSize( 500, 500 );	//set window size to be 512x512 pixels

    glutCreateWindow( "3D Graphics" );  //open a window with the title "2D Graphics"

	//initialize glew if necessary (don't need to on Macs)
#ifndef __APPLE__
	GLenum err = glewInit();
#endif

    init();  //do some initialize for our program
	test();


	//set up the callback functions
    glutDisplayFunc( display );  //REQUIRED.  What to do when it's time to draw
	glutReshapeFunc(resize);
    glutKeyboardFunc( keyboard );  //What to do if a keyboard event is detected
	glutMouseFunc(mymouse);
	glutSpecialFunc(keyboardSpecial);
	glutWMCloseFunc(close);
	glutTimerFunc(10, timerCallback, 0);
	glutTimerFunc(10, snowflaketimer, 1);
    glutMainLoop();  //start infinite loop, listening for events
    return 0;
}

Sphere *sphere;
Cube *cube;
CubeMap *cMap;
Cube *door;

Camera c;
Camera staticCamera(vec4(0, 10, 0,1), vec4(0, 1, 0,0), vec4(0, 0, -1,0));
Camera *currCam;
bool rotate = true;

Plane *xzPlane;
Light flashLight, sun;
Skybox *skybox;

Cube *house;
Light whiteLite;
Sphere *snowball;

Sphere *snowmanBottom, *snowmanBody, *snowmanHead;

std::vector<Drawable*> objs;

bool snowballExists = false;

Cube *houseBottom;

Roof *roof;

Sphere *testSphere;

Drawable* snowballs[2048];
vec4 snowballNormals[2048];
int snowballSteps[2048];

int currSnowball = 0;

Snowflake* snowflake;

void makeSnowball()
{
	vec4 currLoc = currCam->getEye();

	vec3 trans = vec3(currLoc[0], currLoc[1], currLoc[2]);

	snowball = new Sphere();
	

	vec4 mat = vec4(219.0/255.0, 255.0 / 255.0, 255.0 / 255.0, 0.8);

	snowball->setMaterial(mat, mat, mat, 2);
	snowball->setModelMatrix(mat4(1.0));
	snowball->applyTransformation(Translate(trans)*Scale(.2, .2, .2));

	snowballs[currSnowball-1] = snowball;
	
}


int numSnowflakes = 2048;
Snowflake** snowflakes = (Snowflake**) malloc(numSnowflakes * sizeof(Snowflake*));

void makeSnowflakes()
{
	double x, y, z;
	double scale = 20.0;
	for (int i = 0; i < numSnowflakes; i++)
	{
		x = scale*rand() / RAND_MAX;
		y = scale*rand() / RAND_MAX;
		z = scale*rand() / RAND_MAX;
		snowflakes[i] = new Snowflake();
		if (20 * rand() / RAND_MAX < 10.0)
		{
			x = -x;
		}
		if (20 * rand() / RAND_MAX < 10)
		{
			z = -z;
		}
		snowflakes[i]->applyTransformation(Translate(x,y,z));
	}

}


void test()
{
	double smallest = 999.0;
	int loc = 99;
	for (int i = 0; i < 540; i++)
	{
		if (snowflakes[0]->getVertices()[i][1] < smallest)
		{
			smallest = snowflakes[0]->getVertices()[i][1];
			loc = i;
		}
	}
	std::cout << std::endl << std::endl << std::endl << std::endl << std::endl;
	std::cout << "smallest: " << smallest << "   loc: " << loc;
	std::cout << std::endl << std::endl << std::endl << std::endl << std::endl;

}


void init()
{
	theta = 0.0;
	
	glEnable(GL_DEPTH_TEST);

	makeSnowflakes();

	currCam = &c;

	sphere = new Sphere();
	xzPlane = new Plane();
	cube = new Cube();
	skybox = new Skybox();
	cMap = new CubeMap();
	house = new Cube();
	door = new Cube();
	snowball = new Sphere();

	roof = new Roof();

	

	//objs.push_back(sphere);
	objs.push_back(xzPlane);
	objs.push_back(cMap);
	
	objs.push_back(door);

	
	objs.push_back(roof);
	objs.push_back(house);

	snowflake = new Snowflake();
	objs.push_back(snowflake);


	mat4 rY = Translate(2, 1, -4)*RotateY(90.0);



	snowmanBottom = new Sphere();
	snowmanBody = new Sphere();
	snowmanHead = new Sphere();

	snowmanBottom->setModelMatrix(Scale(1.25,1,1.25)*Translate(0,1,0));
	snowmanBody->setModelMatrix(Translate(0, 2.5, 0)*Scale(0.85));
	snowmanHead->setModelMatrix(Translate(0, 3.6, 0)*Scale(0.5));


	objs.push_back(snowmanBottom);
	objs.push_back(snowmanBody);
	objs.push_back(snowmanHead);

	
	snowmanBottom->setMaterial(vec4(1.0,1.0,1.0), vec4(1.0, 1.0, 1.0), vec4(1.0, 1.0, 1.0), 5);
	snowmanBody->setMaterial(vec4(1.0, 1.0, 1.0), vec4(1.0, 1.0, 1.0), vec4(1.0, 1.0, 1.0), 5);
	snowmanHead->setMaterial(vec4(1.0, 1.0, 1.0), vec4(1.0, 1.0, 1.0), vec4(1.0, 1.0, 1.0), 5);
	

	
	staticCamera.setStatic(true);
	staticCamera.createViewMatrix();
	staticCamera.toggleProjectionType();

	c.createViewMatrix();
	c.toggleProjectionType();
	c.setEye(vec4(0,2,0,1));


	for (Drawable* obj : objs)
	{
		obj->setProjectionMatrix(c.getProjectionMatrix());
	}

	for (int i=0; i < numSnowflakes; i++ )
	{
		snowflakes[i]->setProjectionMatrix(c.getProjectionMatrix());
	}


	xzPlane->updateModelMatrix(Scale(50, 50, 50));
	xzPlane->setTexture("ice.ppm");

	cube->transformModelMatrix(Translate(2, 1, -4));

	testSphere = new Sphere();

	testSphere->setModelMatrix(Translate(0,1,0)*mat4(1.0));


	//objs.push_back(testSphere);




	skybox->setNormal(currCam->getN());
	skybox->setV(currCam->getV());


	float sh = 50.0;

	vec4 a(1.0*rand() / RAND_MAX, 1.0*rand() / RAND_MAX, 1.0*rand() / RAND_MAX, 1);
	vec4 s(1.0*rand() / RAND_MAX, 1.0*rand() / RAND_MAX, 1.0*rand() / RAND_MAX, 1);
	vec4 d(1.0*rand() / RAND_MAX, 1.0*rand() / RAND_MAX, 1.0*rand() / RAND_MAX, 1);

	sphere->setMaterial(a, d, s, sh);
	cube->setMaterial(s,a,d,2);


	a = vec4(0, 1, 0, 1);
	d = vec4(1.0, 0.0, 0.0, 1.0);

	vec4 full(1.0, 1.0, 1.0, 1.0);
	//240-248-255	
	vec4(240.0 / 255.0, 248.0 / 255.0, 1.0);
	xzPlane->setMaterial(vec4(240.0 / 255.0, 248.0 / 255.0, 1.0), vec4(240.0 / 255.0, 248.0 / 255.0, 1.0), vec4(240.0 / 255.0, 248.0 / 255.0, 1.0),1);
	// a d s sh

	vec4 color(1.0,0.5,0.5, 1);
	flashLight = Light(currCam->getEye(), vec4(0,0,0,1.0), color, color);

	vec4 color2(255.0 / 255.0, 128.0 / 255.0, 0, 1);
	sun = Light(vec4(0, 0, 0, 0), color2, color2, color2);
	whiteLite = Light(vec4(0,0,0,1), vec4(1, 1, 1, 1), vec4(1, 1, 1, 1), vec4(1, 1, 1, 1));
	

	house->setTexture("house.ppm");
	house->setMaterial(vec4(1.0, 1.0, 1.0), vec4(1.0, 1.0, 1.0), vec4(1.0, 1.0, 1.0), 2);

	roof->setMaterial(vec4(1.0, 1.0, 1.0), vec4(1.0, 1.0, 1.0), vec4(1.0, 1.0, 1.0), 100);

	door->setTexture("door.ppm");
	door->setMaterial(vec4(1.0, 1.0, 1.0), vec4(1.0, 1.0, 1.0), vec4(1.0, 1.0, 1.0), 0);
	door->updateModelMatrix(Scale(0.5,2,0.5)*Translate(-20, 0, -20));

	vec4 * p = house->getPoints();


	glClearColor( 1.0, 1.0, 1.0, 1.0 );
	
}


bool view = true;
//----------------------------------------------------------------------------
// switch to VAO, make sure to change to the right program, and give values to all of the uniform variables in the shader program
void display( void )
{
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );  //clear out the color of the framebuffer and the depth info from the depth buffer

	flashLight.setPosition(currCam->getEye());
	
	skybox->setNormal(currCam->getN());
	skybox->setV(currCam->getV());
	skybox->draw();

	//LookAt(vec4(0, 0, 0, 1), vec4(0, 0, 0, 1) - currNormal, currV);

	for (Drawable* obj : objs)
	{
		if (obj != xzPlane)
		{
			obj->setLight(flashLight, 0);
			obj->setLight(whiteLite, 1);
			obj->updateViewMatrix(currCam->getViewMatrix());
			obj->draw();
		}	
	}

	for (int i = 0; i < currSnowball; i++)
	{
		if (((Sphere*)snowballs[i])->getActivated())
		{
			snowballs[i]->updateViewMatrix(currCam->getViewMatrix());
			snowballs[i]->draw();
		}
	}

	for (int i = 0; i < numSnowflakes; i++)
	{
		snowflakes[i]->updateViewMatrix(currCam->getViewMatrix());
		snowflakes[i]->draw();
	}


	xzPlane->setLight(flashLight, 0);
	xzPlane->setLight(whiteLite, 1);
	xzPlane->updateViewMatrix(currCam->getViewMatrix());
	xzPlane->draw();


	GLenum err;
	while ((err = glGetError()) != GL_NO_ERROR) {
		std::cout << "OpenGL error: " << err << "     " << gluErrorString(err) << "|" << std::endl;
	}

	glutSwapBuffers();
}

void mymouse(GLint button, GLint state, GLint x, GLint y)
{

	glutPostRedisplay();
}

//----------------------------------------------------------------------------
bool currStatic = false;
int numSteps = 0;
vec4 setNorm = vec4();
void keyboard( unsigned char key, int x, int y )
{
    switch( key ) {

	case 'x':
		currCam->rotateU(2);
		glutPostRedisplay();
		break;
	case 'X':
		currCam->rotateU(-2);
		glutPostRedisplay();
		break;
	case 'c':
		currCam->rotateV(-2);
		glutPostRedisplay();
		break;
	case 'C':
		currCam->rotateV(2);
		glutPostRedisplay();
		break;
	case 'z':
		currCam->rotateN(-2);
		glutPostRedisplay();
		break;
	case 'Z':
		currCam->rotateN(2);
		glutPostRedisplay();
		break;
	case ' ':
		flashLight.toggle();
		glutPostRedisplay();
		break;
	case 'l':
		currSnowball++;
		snowballSteps[currSnowball-1] = 0;
		snowballNormals[currSnowball-1] = -.1 * currCam->getN();
		makeSnowball();
		
		break;
	case 't':
		if (currTexture == 0)
		{
			currTexture = 1;
		}
		else
		{
			currTexture = 0;
		}
		cube->setTexture(textures[currTexture]);
		glutPostRedisplay();
		break;
	case 'T':
		if (currTexture == 0)
		{
			currTexture = 1;
		}
		else
		{
			currTexture = 0;
		}
		cube->setTexture(textures[currTexture]);
		glutPostRedisplay();
		break;
	case 033:  // Escape key
	case 'q': case 'Q':
	    exit( EXIT_SUCCESS );
	    break;
    }
}

void keyboardSpecial(int key, int x, int y)
{
	vec4 rayOrigin;
	vec4 ray;
	switch (key) {
	case GLUT_KEY_UP:
		currCam->moveForward();
		break;
	case GLUT_KEY_DOWN:
		currCam->moveBackward();
		break;
	case GLUT_KEY_RIGHT:
		currCam->moveRight();
		break;
	case GLUT_KEY_LEFT:
		currCam->moveLeft();
		break;
	}
	glutPostRedisplay();
}

void close(){
	//glDeleteBuffers(1, &buffer);  //delete the buffers (free up space on GPU)

}




void timerCallback(int value)
{
	vec4 currT;
	for (int i = 0; i < currSnowball; i++)
	{	
		currT = 0.95*snowballNormals[i] + (snowballSteps[i] / 500.0)*vec4(0, -0.1, 0, 1);
		((Sphere*)snowballs[i])->applyTransformation(Translate(currT[0], currT[1], currT[2]));
		
		if (((Sphere*)snowballs[i])->getActivated() && snowballSteps[i] < 500)
		{
			snowballSteps[i]++;
		}
		else
		{
			((Sphere*)snowballs[i])->deactivate();
		}
	}



	glutTimerFunc(10, timerCallback, 0);

	glutPostRedisplay();

}
/*
	axis:
		0 is x
		1 is y
		2 is z
*/
float getForces(int axis)
{
	if (axis == 0)		// x movement
	{
		return 0.0;
	}
	else if (axis == 1) // y movement
	{
		return -1.0;
	}
	else				// z movement
	{
		return 0.0;
	}
}

bool collision(int snowflake)
{
	snowflakes[snowflake]->getFullVelocity();
	mat4 mm = snowflakes[snowflake]->getModelMatrix();
	
	if ( (mm * snowflakes[snowflake]->getVertices()[252]).y < 0.0)
	{
		snowflakes[snowflake]->setVelocity(0.0, 0);
		snowflakes[snowflake]->setVelocity(0.0, 1);
		snowflakes[snowflake]->setVelocity(0.0, 2);

	}

	return true;
}

void snowflaketimer(int value)
{
	vec3 velocity;
	for (int i = 0; i < numSnowflakes; i++)
	{
		
		for (int j = 0; j < 3; j++)
		{
			snowflakes[i]->setVelocity((snowflakes[i]->getVelocity(j) + getForces(j))/100.0, j);
		}
		
		collision(i);

		snowflakes[i]->applyTransformation(Translate(snowflakes[i]->getVelocity(0), 
													 snowflakes[i]->getVelocity(1), 
													 snowflakes[i]->getVelocity(2)));
	}

	glutTimerFunc(10, snowflaketimer, 1);

	glutPostRedisplay();
}

void resize(int w, int h) {
	std::cout << w << " " << h << std::endl;
	if (w > h)
	{
		glViewport(0, 0, h, h);
	}
	else
	{
		glViewport(0, 0, w, w);
	}
	

}