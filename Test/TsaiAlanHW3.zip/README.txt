Alan Tsai

The program was build in VS. It should draw the polyhedron, 
flying camera, arrow keys and switching between projection
and orthogonal should all be working. 